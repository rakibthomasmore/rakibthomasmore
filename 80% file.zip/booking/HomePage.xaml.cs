﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace booking
{
    public partial class HomePage : Page
    {
        private readonly DispatcherTimer _slideshowTimer;
        private readonly string[] _imagePaths;
        private int _currentImageIndex;

        public HomePage()
        {
            InitializeComponent();

            _imagePaths = new string[]
            {
                "C:/Users/user/Downloads/3.jpg",
                "C:/Users/user/Downloads/2.jpg",
                "C:/Users/user/Downloads/4.jpg"
            };

            _slideshowTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(5)
            };

            InitializeSlideshow();
           
        }

        private void InitializeSlideshow()
        {
            _currentImageIndex = 0;
            SlideshowImage.Source = new BitmapImage(new Uri(_imagePaths[_currentImageIndex], UriKind.Absolute));

            _slideshowTimer.Tick += OnSlideshowTimerTick;
            _slideshowTimer.Start();
        }

        private void OnSlideshowTimerTick(object sender, EventArgs e)
        {
            _currentImageIndex = (_currentImageIndex + 1) % _imagePaths.Length;
            SlideshowImage.Source = new BitmapImage(new Uri(_imagePaths[_currentImageIndex], UriKind.Absolute));
        }

        private void BookNow_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new BookingPage());
        }

        private void Facebook_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenUrl("https://www.facebook.com/people/PetHostel/61559459909916/");
        }

        private void Twitter_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenUrl("https://twitter.com/YourTwitterHandle");
        }

        private void Instagram_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenUrl("https://www.instagram.com/YourInstagramHandle");
        }

        private void OpenUrl(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url)
                {
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to open the link: {ex.Message}");
            }
        }
    }
}




