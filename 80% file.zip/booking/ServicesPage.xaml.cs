﻿using System.Windows.Controls;

namespace booking
{
    public partial class ServicesPage : Page
    {
        public ServicesPage()
        {
            InitializeComponent();
        }
    }
}


