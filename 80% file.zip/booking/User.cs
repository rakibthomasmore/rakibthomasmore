﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BCrypt.Net;

namespace booking
{
    public class User
    {
        public int UserId { get; set; }
        public string? Username { get; set; }
        // Store the hash, not the plain password for security
        public string? PasswordHash { get; set; }
        public string? Email { get; set; }
        

        // Method to hash the password and store the hash
        public void SetPassword(string password)
        {
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(password);
        }

        // Method to verify if a provided password matches the stored hash
        public bool VerifyPassword(string password)
        {
            return BCrypt.Net.BCrypt.Verify(password, PasswordHash);
        }
    }
}
