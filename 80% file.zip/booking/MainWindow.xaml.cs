﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace booking
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigated += OnNavigated;
            MainFrame.Navigate(new LoginPage()); // Navigate to login page initially
        }

        private void OnNavigated(object sender, NavigationEventArgs e)
        {
            // Hide navigation menu for LoginPage and SignupPage
            var navigationMenu = (StackPanel)((Border)((DockPanel)this.Content).Children[0]).Child;
            if (e.Content is LoginPage || e.Content is SignUpPage)
            {
                navigationMenu.Visibility = Visibility.Collapsed;
            }
            else
            {
                navigationMenu.Visibility = Visibility.Visible;
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new HomePage());
        }

        private void Services_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ServicesPage());
        }

        private void ViewBookings_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ViewBookingsPage());
        }

        private void ContactUs_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ContactPage());
        }
        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AboutUsPage());
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logging out...");
            MainFrame.Navigate(new LoginPage());
        }
    }
}






