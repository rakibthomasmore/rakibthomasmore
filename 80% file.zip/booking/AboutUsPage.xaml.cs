﻿using System.Windows.Controls;

namespace booking
{
    public partial class AboutUsPage : Page
    {
        public AboutUsPage()
        {
            InitializeComponent();
        }
    }
}

