﻿using System.Windows;

namespace booking
{
    public partial class WelcomeWindow : Window
    {
        public WelcomeWindow()
        {
            InitializeComponent();
        }

        private void LogInButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.MainFrame.Navigate(new LoginPage());
            mainWindow.Show();
            this.Close();
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.MainFrame.Navigate(new SignUpPage());
            mainWindow.Show();
            this.Close();
        }
    }
}
