﻿using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class SignUpPage : Page
    {
        private readonly DatabaseHelper _dbHelper = new DatabaseHelper();

        public SignUpPage()
        {
            InitializeComponent();
        }

        private async void CreateAccountButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var email = EmailTextBox.Text;
            var password = PasswordBox.Password;
            var confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password) || password != confirmPassword)
            {
                MessageBox.Show("Please fill in all fields correctly.");
                return;
            }

            bool success = await CreateUserAsync(username, email, password);

            if (success)
            {
                MessageBox.Show("Account created successfully. Please log in.");
                NavigationService.Navigate(new LoginPage());
            }
            else
            {
                MessageBox.Show("Failed to create account. Please try again.");
            }
        }

        private async Task<bool> CreateUserAsync(string username, string email, string password)
        {
            return await _dbHelper.CreateUserAsync(username, email, password);
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && textBox.Name == "UsernameTextBox")
            {
                UsernameWatermark.Visibility = Visibility.Collapsed;
            }
            else if (sender is TextBox emailTextBox && emailTextBox.Name == "EmailTextBox")
            {
                EmailTextBoxWatermark.Visibility = Visibility.Collapsed;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sender is TextBox textBox && textBox.Name == "UsernameTextBox")
            {
                if (string.IsNullOrEmpty(UsernameTextBox.Text))
                {
                    UsernameWatermark.Visibility = Visibility.Visible;
                }
            }
            else if (sender is TextBox emailTextBox && emailTextBox.Name == "EmailTextBox")
            {
                if (string.IsNullOrEmpty(EmailTextBox.Text))
                {
                    EmailTextBoxWatermark.Visibility = Visibility.Visible;
                }
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox passwordBox && passwordBox.Name == "PasswordBox")
            {
                PasswordWatermark.Visibility = Visibility.Collapsed;
            }
            else if (sender is PasswordBox confirmPasswordBox && confirmPasswordBox.Name == "ConfirmPasswordBox")
            {
                ConfirmPasswordWatermark.Visibility = Visibility.Collapsed;
            }
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox passwordBox && passwordBox.Name == "PasswordBox")
            {
                if (string.IsNullOrEmpty(PasswordBox.Password))
                {
                    PasswordWatermark.Visibility = Visibility.Visible;
                }
            }
            else if (sender is PasswordBox confirmPasswordBox && confirmPasswordBox.Name == "ConfirmPasswordBox")
            {
                if (string.IsNullOrEmpty(ConfirmPasswordBox.Password))
                {
                    ConfirmPasswordWatermark.Visibility = Visibility.Visible;
                }
            }
        }
    }
}

