﻿using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class NavigationBar : UserControl
    {
        public NavigationBar()
        {
            InitializeComponent();
        }

        private void NavigateHome_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow)?.MainFrame.Navigate(new HomePage());
        }

        private void NavigateServices_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow)?.MainFrame.Navigate(new ServicesPage());
        }

        private void NavigateViewBookings_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow)?.MainFrame.Navigate(new ViewBookingsPage());
        }

        private void NavigateContact_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow)?.MainFrame.Navigate(new ContactPage());
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            (Application.Current.MainWindow as MainWindow)?.MainFrame.Navigate(new LoginPage());
        }
    }
}












