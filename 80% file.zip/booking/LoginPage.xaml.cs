﻿using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class LoginPage : Page
    {
        private readonly DatabaseHelper _dbHelper = new DatabaseHelper();

        public LoginPage()
        {
            InitializeComponent();
        }

        public async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            // Assuming DatabaseHelper contains a method for validating user credentials
            bool isValidUser = await _dbHelper.ValidateUserAsync(username, password);

            if (isValidUser)
            {
                MessageBox.Show("Login successful!");

                // After successful login validation
                UserSession.CurrentUserName = username;
                NavigationService.Navigate(new HomePage());
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.");
            }
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new SignUpPage());
        }

        private void UsernameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UsernameHint.Visibility = string.IsNullOrEmpty(UsernameTextBox.Text) ? Visibility.Visible : Visibility.Hidden;
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordHint.Visibility = string.IsNullOrEmpty(PasswordBox.Password) ? Visibility.Visible : Visibility.Hidden;
        }

        public static class UserSession
        {
            public static string CurrentUserName { get; set; }
            // Add other session-related properties here
        }
    }
}


