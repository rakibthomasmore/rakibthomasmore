﻿using bookingViewmodel;
using System;
using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class BookingPage : Page
    {
        private readonly BookingViewModel _bookingViewModel;

        public BookingPage()
        {
            InitializeComponent();
            _bookingViewModel = new BookingViewModel();
            this.DataContext = _bookingViewModel;
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool bookingIsSuccessful = await _bookingViewModel.CreateBookingAsync();
                if (bookingIsSuccessful)
                {
                    MessageBox.Show("Booking created successfully!");
                    NavigationService.Navigate(new PaymentPage(_bookingViewModel));
                }
                else
                {
                    MessageBox.Show("Booking creation failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }
}



