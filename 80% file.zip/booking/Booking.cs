﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace booking
{
    public class Booking
    {
        public int Id { get; set; }
        public int? ServiceId { get; set; } // Changed to nullable int
        public int? PetId { get; set; } // Changed to nullable int
        public DateTime BookingDate { get; set; }
        public string BookingTime { get; set; }
        public string ContactNumber { get; set; }
        public string SpecialRequests { get; set; }
        public string ServiceName { get; set; }
        public string PetName { get; set; }
        public string UserName { get; set; }
        // Add other properties as needed
    }

}