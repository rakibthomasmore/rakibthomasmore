﻿using System;
using System.Windows.Controls;
using System.Windows;
using static booking.LoginPage;

namespace booking
{
    /// <summary>
    /// Interaction logic for ViewBookingsPage.xaml
    /// </summary>
    public partial class ViewBookingsPage : Page
    {
        private DatabaseHelper _dbHelper = new DatabaseHelper();

        public ViewBookingsPage()
        {
            InitializeComponent();
            LoadBookingsAsync();
        }

        public async void LoadBookingsAsync()
        {
            try
            {
                var bookings = await _dbHelper.GetBookingsAsync(UserSession.CurrentUserName);
                BookingsItemsControl.ItemsSource = bookings;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load bookings: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
