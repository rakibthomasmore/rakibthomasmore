﻿using bookingViewmodel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class PaymentPage : Page
    {
        public PaymentPage(BookingViewModel bookingViewModel)
        {
            InitializeComponent();
            this.DataContext = bookingViewModel;
        }

        private void ConfirmPayment_Click(object sender, RoutedEventArgs e)
        {
            var selectedMethod = PaymentMethodsPanel.Children.OfType<RadioButton>()
                              .FirstOrDefault(r => r.IsChecked == true)?.Tag.ToString();

            switch (selectedMethod)
            {
                case "CreditCard":
                    PayWithCreditCard_Click(sender, e);
                    break;
                case "PayPal":
                    PayWithPayPal_Click(sender, e);
                    break;
                case "BankTransfer":
                    BankTransfer_Click(sender, e);
                    break;
                default:
                    MessageBox.Show("Please select a payment method.", "Payment", MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;
            }
        }

        private void PayWithCreditCard_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Credit Card payment is selected.", "Payment", MessageBoxButton.OK, MessageBoxImage.Information);
            // Navigate to CreditCardPaymentPage or implement payment logic
            // CreditCardPaymentPage creditCardPaymentPage = new CreditCardPaymentPage();
            // this.NavigationService.Navigate(creditCardPaymentPage);
        }

        private void PayWithPayPal_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("PayPal payment is selected.", "Payment", MessageBoxButton.OK, MessageBoxImage.Information);
            // Implement payment logic or redirect to PayPal payment service
        }

        private void BankTransfer_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Bank Transfer payment is selected.", "Payment", MessageBoxButton.OK, MessageBoxImage.Information);
            // Navigate to BankTransferDetailsPage or implement payment logic
            // BankTransferDetailsPage bankTransferDetailsPage = new BankTransferDetailsPage();
            // this.NavigationService.Navigate(bankTransferDetailsPage);
        }
    }
}



