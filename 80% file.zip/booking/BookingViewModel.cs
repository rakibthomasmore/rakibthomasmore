﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Input;
using MySql.Data.MySqlClient;
using Xceed.Wpf.Toolkit;
using booking;
using static booking.LoginPage;
using System.Data;

namespace bookingViewmodel
{
    public class BookingViewModel : INotifyPropertyChanged
    {
        private DatabaseHelper _dbHelper = new DatabaseHelper();
        private Service _selectedService;
        private Pet _selectedPet;
        private DateTime? _selectedDate;
        private string _contactNumber;
        private const decimal TaxRate = 0.15m; // 15% tax rate
        public decimal SelectedServicePrice { get; set; }

        public ObservableCollection<Service> AvailableServices { get; private set; }
        public ObservableCollection<Pet> AvailablePets { get; private set; }

        // Commands
        public ICommand CreateBookingCommand { get; private set; }

        public BookingViewModel()
        {
            AvailableServices = new ObservableCollection<Service>();
            AvailablePets = new ObservableCollection<Pet>();
            CreateBookingCommand = new AsyncRelayCommand(CreateBookingAsync);

            // Load available services and pets
            LoadAvailableServicesAsync().ConfigureAwait(false);
            LoadAvailablePetsAsync().ConfigureAwait(false);
            LoadBookings();
        }

        private ObservableCollection<Booking> _bookings = new ObservableCollection<Booking>();
        public ObservableCollection<Booking> Bookings
        {
            get { return _bookings; }
            set
            {
                _bookings = value;
                OnPropertyChanged(nameof(Bookings));
            }
        }

        // Properties for binding
        public Service SelectedService
        {
            get => _selectedService;
            set
            {
                if (_selectedService != value)
                {
                    _selectedService = value;
                    OnPropertyChanged(nameof(SelectedService));
                    UpdateInvoice(); // Call this method to update tax and total amount when service changes
                }
            }
        }

        public decimal TaxAmount
        {
            get => _selectedService != null ? _selectedService.Price * TaxRate : 0m;
        }
        public decimal TotalAmount
        {
            get => _selectedService != null ? _selectedService.Price + TaxAmount : 0m;
        }

        // Call this method to update the invoice when the selected service changes
        private void UpdateInvoice()
        {
            OnPropertyChanged(nameof(TaxAmount));
            OnPropertyChanged(nameof(TotalAmount));
        }

        public Pet SelectedPet
        {
            get => _selectedPet;
            set
            {
                _selectedPet = value;
                OnPropertyChanged(nameof(SelectedPet));
            }
        }

        private DateTime? _selectedTime;
        public DateTime? SelectedTime
        {
            get { return _selectedTime; }
            set
            {
                if (_selectedTime != value) // Check if the value is actually changing to avoid unnecessary notifications
                {
                    _selectedTime = value;
                    OnPropertyChanged(nameof(SelectedTime));
                }
            }
        }

        public string ContactNumber
        {
            get => _contactNumber;
            set
            {
                _contactNumber = value;
                OnPropertyChanged(nameof(ContactNumber));
            }
        }

        private string _specialRequests;
        public string SpecialRequests
        {
            get => _specialRequests;
            set
            {
                _specialRequests = value;
                OnPropertyChanged(nameof(SpecialRequests));
            }
        }

        private DateTime? selectedDate;
        public DateTime? SelectedDate
        {
            get { return selectedDate; }
            set
            {
                if (selectedDate != value)
                {
                    selectedDate = value;
                    OnPropertyChanged(nameof(SelectedDate));
                }
            }
        }

        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnPropertyChanged(nameof(UserName)); // Assuming INotifyPropertyChanged implementation
            }
        }

        public async Task<bool> CreateBookingAsync()
        {
            string connectionString = "server=localhost;database=booking;uid=root;pwd=@Green420@;";
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    string query = @"
    INSERT INTO Bookings (ServiceId, PetId, BookingDate, BookingTime, ContactNumber, SpecialRequests, UserName) 
    VALUES (@ServiceId, @PetId, @BookingDate, @BookingTime, @ContactNumber, @SpecialRequests, @UserName)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ServiceId", SelectedService.Id);
                        command.Parameters.AddWithValue("@PetId", SelectedPet.Id);
                        command.Parameters.AddWithValue("@BookingDate", SelectedDate.HasValue ? (object)SelectedDate.Value.Date : DBNull.Value);
                        command.Parameters.AddWithValue("@BookingTime", SelectedTime.HasValue ? (object)SelectedTime.Value.ToString(@"hh\:mm\:ss") : DBNull.Value);
                        command.Parameters.AddWithValue("@ContactNumber", ContactNumber ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@SpecialRequests", SpecialRequests ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@UserName", UserSession.CurrentUserName ?? (object)DBNull.Value);

                        int result = await command.ExecuteNonQueryAsync();
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Consider logging the exception details
                System.Windows.MessageBox.Show($"Failed to create booking: {ex.Message}");
                return false;
            }
        }

        private async void LoadBookings()
        {
            // Assuming you have a method in your DatabaseHelper to fetch bookings
            var bookings = await new DatabaseHelper().GetBookingsAsync(UserSession.CurrentUserName);
            foreach (var booking in bookings)
            {
                Bookings.Add(booking);
            }
        }

        private async Task LoadAvailableServicesAsync()
        {
            string connectionString = "server=localhost;database=booking;uid=root;pwd=@Green420@;";
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    string query = "SELECT Id, Name, Description, Price FROM Services"; // Make sure column names match your database
                                                                                        // Adjust this query as needed for your database schema

                    using (var command = new MySqlCommand(query, connection))
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var service = new Service
                            {
                                Id = reader.GetInt32("Id"),
                                Name = reader.GetString("Name"),

                                Price = reader.GetDecimal("Price")
                            };
                            AvailableServices.Add(service);
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                System.Windows.MessageBox.Show($"Database connection error: {ex.Message}");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private async Task LoadAvailablePetsAsync()
        {
            string connectionString = "server=localhost;database=booking;uid=root;pwd=@Green420@;";
            using (var connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();
                string query = "SELECT * FROM Pets"; // Adjust this query as needed for your database schema

                using (var command = new MySqlCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var pet = new Pet
                        {
                            Id = reader.GetInt32("Id"), // Adjust the column name as per your schema
                            Name = reader.GetString("Name") // Adjust the column name as per your schema
                        };
                        AvailablePets.Add(pet);
                    }
                }
            }
        }

        private async void LoadBookingsAsync()
        {
            // Example method to load bookings from the database
            var bookings = await _dbHelper.GetBookingsAsync(UserSession.CurrentUserName);
            foreach (var booking in bookings)
            {
                Bookings.Add(booking);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // RelayCommand implementation
    public class RelayCommand : ICommand
    {
        private Action<object> execute;
        private Func<object, bool> canExecute;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return this.canExecute == null || this.canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            this.execute(parameter);
        }
    }

    // Assuming these classes are defined in your project
    public class Service
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public decimal Price { get; set; }
    }

    public class Pet
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}


