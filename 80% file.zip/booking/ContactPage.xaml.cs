﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace booking
{
    public partial class ContactPage : Page
    {
        public ContactPage()
        {
            InitializeComponent();
        }

        private void EmailUs_Click(object sender, RoutedEventArgs e)
        {
            var mailto = new Uri("mailto:pethostel@gmail.com?subject=petupdate&body=UpdateMyPetPlease.");
            var psi = new ProcessStartInfo
            {
                FileName = mailto.AbsoluteUri,
                UseShellExecute = true
            };

            try
            {
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to open the email client: {ex.Message}");
            }
        }

        private void CallUs_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText("123-456-7890");
            MessageBox.Show("Our phone number has been copied to your clipboard.");
        }

        private void Twitter_Click(object sender, RoutedEventArgs e)
        {
            OpenUrl("https://twitter.com/pethostel");
        }

        private void Facebook_Click(object sender, RoutedEventArgs e)
        {
            OpenUrl("https://www.facebook.com/profile.php?id=61559459909916");
        }

        private void Instagram_Click(object sender, RoutedEventArgs e)
        {
            OpenUrl("https://www.instagram.com/pethostel");
        }

        private void OpenUrl(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url)
                {
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to open the link: {ex.Message}");
            }
        }
    }
}


